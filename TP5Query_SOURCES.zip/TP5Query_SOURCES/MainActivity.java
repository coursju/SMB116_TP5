package com.smb116.tp5query;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.loader.app.LoaderManager;

import android.app.Activity;
import android.app.ListActivity;
import android.content.ComponentName;
import android.content.ContentProviderClient;
import android.content.CursorLoader;
import android.content.Loader;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements  android.app.LoaderManager.LoaderCallbacks<Cursor> {

    private static final String TAG = MainActivity.class.getName();
    private List<String> intListString;

    /** Question 5 */
    public final String AUTHORITY = "com.smb116.tp5.provider.MyContentProvider";
    public final String TABLE_NAME = "intervenant";
    public final Uri URI_INTERVENANT = Uri.parse("content://" + AUTHORITY + "/" + TABLE_NAME);

    private TextView queryTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.queryTxt = findViewById(R.id.queryTxt);

        /** Question 5 */
        getLoaderManager().initLoader(1, null, this);
        checkPermission();
    }

    public List<String> getListFromCursor(Cursor cursor){
        List<String> list = new ArrayList<>();

        while (cursor.moveToNext()){
            list.add(cursor.getString(1)+" "+cursor.getString(2)+" \n"+cursor.getString(3));
        }
        return list;
    }

    public void checkPermission()  {
        if (ContextCompat.checkSelfPermission(this, "com.smb116.tp5.provider") == PackageManager.PERMISSION_GRANTED) {
            onCreateLoader(1, null);
        }
        else {
            ActivityCompat.requestPermissions(this, new String[]{"com.smb116.tp5.provider"}, 2);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        switch (requestCode) {
            case 2:
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    onCreateLoader(1, null);
                }  else {
                    Toast.makeText(getApplicationContext(),"The permission is needed to launch the next activity!",Toast.LENGTH_LONG).show();
                }
                return;
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Log.i(TAG, "onCreateLoader");
        return new CursorLoader(this, URI_INTERVENANT, null, null, null, null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        Log.i(TAG, "onLoadFinished");
        Random r = new Random();
        int nb = r.nextInt((3 - 1)+1)+1;
        Log.i(TAG, String.valueOf(nb));

        if (data != null) {
            intListString = getListFromCursor(data);
            this.queryTxt.setText(intListString.get(nb-1));
        }else{
            Log.i(TAG, "cursor null");
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }
}